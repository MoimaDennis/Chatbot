﻿// MainWindow.xaml.cs - 15 Unique Paraphrased Quiz Questions
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace dennisChatbotXAML
{
    public partial class MainWindow : Window
    {
        private int currentQuestionIndex = 0;
        private int score = 0;
        private List<QuizQuestion> questions = new List<QuizQuestion>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void NLPInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            string input = NLPInput.Text.ToLower();

            if (input.Contains("add task"))
                ChatResponse.Text = "You can use the task section to add it.";
            else if (input.Contains("remind me"))
                ChatResponse.Text = "Don't forget to set a reminder date above.";
            else if (input.Contains("quiz"))
                ChatResponse.Text = "Click 'Start Quiz' to begin.";
            else
                ChatResponse.Text = "I'm here to help with cybersecurity!";
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            string title = TaskTitle.Text;
            string description = TaskDescription.Text;
            DateTime? reminder = ReminderDate.SelectedDate;

            string taskSummary = $"{title} - {description} (Reminder: {reminder?.ToShortDateString() ?? "None"})";
            TaskList.Items.Add(taskSummary);

            ChatResponse.Text = $"Task added: {title}";

            LogActivity($"Task added: '{title}' with reminder {(reminder.HasValue ? reminder.Value.ToShortDateString() : "None")}");
        }

        private void LogActivity(string action)
        {
            if (LogList != null)
            {
                LogList.Items.Insert(0, $"{DateTime.Now}: {action}");
                if (LogList.Items.Count > 10)
                    LogList.Items.RemoveAt(10);
            }
        }

        private void StartQuiz_Click(object sender, RoutedEventArgs e)
        {
            currentQuestionIndex = 0;
            score = 0;
            LoadQuizQuestions();
            ShowQuestion();
            LogActivity("Quiz started");
        }

        private void SubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            if (questions.Count == 0 || currentQuestionIndex >= questions.Count)
            {
                ChatResponse.Text = "Please click 'Start Quiz' to begin.";
                return;
            }

            int selectedOption = -1;
            if (OptionA.IsChecked == true) selectedOption = 0;
            else if (OptionB.IsChecked == true) selectedOption = 1;
            else if (OptionC.IsChecked == true) selectedOption = 2;
            else if (OptionD.IsChecked == true) selectedOption = 3;

            if (selectedOption == -1)
            {
                ExplanationText.Text = "⚠️ Please select an answer before submitting.";
                return;
            }

            var currentQuestion = questions[currentQuestionIndex];

            if (selectedOption == currentQuestion.CorrectIndex)
            {
                score++;
                ExplanationText.Text = "✅ Correct! " + currentQuestion.Explanation;
                LogActivity($"Question {currentQuestionIndex + 1}: Correct");
            }
            else
            {
                ExplanationText.Text = "❌ Incorrect. " + currentQuestion.Explanation;
                LogActivity($"Question {currentQuestionIndex + 1}: Incorrect");
            }

            currentQuestionIndex++;

            if (currentQuestionIndex < questions.Count)
            {
                ShowQuestion();
            }
            else
            {
                QuestionText.Text = "🎉 Quiz Complete!";
                ExplanationText.Text += $"\n\nYour final score is {score}/{questions.Count}. Click 'Start Quiz' to try again.";
                LogActivity($"Quiz completed - Final Score: {score}");

                OptionA.Content = "";
                OptionB.Content = "";
                OptionC.Content = "";
                OptionD.Content = "";

                OptionA.IsChecked = false;
                OptionB.IsChecked = false;
                OptionC.IsChecked = false;
                OptionD.IsChecked = false;
            }
        }

        private void ShowQuestion()
        {
            if (currentQuestionIndex >= questions.Count)
                return;

            var q = questions[currentQuestionIndex];
            QuestionText.Text = $"Q{currentQuestionIndex + 1}: {q.QuestionText}";
            OptionA.Content = q.Options[0];
            OptionB.Content = q.Options[1];
            OptionC.Content = q.Options[2];
            OptionD.Content = q.Options[3];

            OptionA.IsChecked = false;
            OptionB.IsChecked = false;
            OptionC.IsChecked = false;
            OptionD.IsChecked = false;

            ExplanationText.Text = "";
        }

        private void ShowLog_Click(object sender, RoutedEventArgs e)
        {
            string log = "";
            foreach (var item in LogList.Items)
            {
                log += item.ToString() + "\n";
            }

            MessageBox.Show(string.IsNullOrWhiteSpace(log) ? "No activity yet." : log, "Activity Log");
        }

        private void LoadQuizQuestions()
        {
            questions.Clear();

            questions.Add(new QuizQuestion { QuestionText = "How should you respond to an email that asks for your login credentials?", Options = new[] { "Send your login details", "Delete immediately", "Mark it as phishing", "Ignore it" }, CorrectIndex = 2, Explanation = "Phishing emails should be reported to protect others." });
            questions.Add(new QuizQuestion { QuestionText = "Which password provides the highest level of security?", Options = new[] { "123456", "Admin", "Welcome1", "5h&L@8p#Kz" }, CorrectIndex = 3, Explanation = "Secure passwords combine symbols, digits, and mixed case." });
            questions.Add(new QuizQuestion { QuestionText = "What is the main job of a firewall?", Options = new[] { "Display ads", "Monitor data usage", "Block unauthorized access", "Boost Wi-Fi speed" }, CorrectIndex = 2, Explanation = "Firewalls help control traffic based on rules." });
            questions.Add(new QuizQuestion { QuestionText = "When browsing online, what is a good habit?", Options = new[] { "Download from pop-ups", "Use websites with HTTPS", "Click unknown links", "Install random extensions" }, CorrectIndex = 1, Explanation = "HTTPS ensures encrypted communication with websites." });
            questions.Add(new QuizQuestion { QuestionText = "What term describes tricking users to give away sensitive info?", Options = new[] { "Fishing", "Cryptography", "Phishing", "Cloning" }, CorrectIndex = 2, Explanation = "Phishing relies on human error to steal information." });
            questions.Add(new QuizQuestion { QuestionText = "Which method is considered multi-factor authentication?", Options = new[] { "Just a password", "Email and password", "Code sent to phone + password", "Username and name" }, CorrectIndex = 2, Explanation = "Combining what you know and what you have improves security." });
            questions.Add(new QuizQuestion { QuestionText = "What is the best description of malware?", Options = new[] { "Helpful software", "Infected hardware", "Harmful software", "Computer component" }, CorrectIndex = 2, Explanation = "Malware is software that harms your device or steals data." });
            questions.Add(new QuizQuestion { QuestionText = "How can you spot a fraudulent website?", Options = new[] { "Fast loading", "Incorrect spelling in URL", "Bright colors", "Working links" }, CorrectIndex = 1, Explanation = "Fraudulent sites often use misspelled domain names." });
            questions.Add(new QuizQuestion { QuestionText = "Why should you install updates regularly?", Options = new[] { "To use more space", "To avoid security risks", "For gaming", "To make it slower" }, CorrectIndex = 1, Explanation = "Updates patch known vulnerabilities." });
            questions.Add(new QuizQuestion { QuestionText = "What does data encryption do?", Options = new[] { "Delete data", "Compress files", "Secure information", "Send files" }, CorrectIndex = 2, Explanation = "Encryption turns data into unreadable format unless decrypted." });
            questions.Add(new QuizQuestion { QuestionText = "What is the first thing you should do when hit by ransomware?", Options = new[] { "Ignore it", "Pay the attacker", "Disconnect and seek help", "Reboot system" }, CorrectIndex = 2, Explanation = "Disconnecting can stop the malware from spreading." });
            questions.Add(new QuizQuestion { QuestionText = "Which one is considered personal identifiable information?", Options = new[] { "Search history", "Credit card number", "IP address", "Battery level" }, CorrectIndex = 1, Explanation = "PII includes sensitive info like card numbers." });
            questions.Add(new QuizQuestion { QuestionText = "Which technique is used to mimic a legitimate source?", Options = new[] { "Ducking", "Spoofing", "Logging", "Chaining" }, CorrectIndex = 1, Explanation = "Spoofing tricks users into thinking communication is legitimate." });
            questions.Add(new QuizQuestion { QuestionText = "What should a strong password contain?", Options = new[] { "Only lowercase letters", "Your birthday", "Mix of letters, numbers, symbols", "Your pet’s name" }, CorrectIndex = 2, Explanation = "Strong passwords are long and unpredictable." });
            questions.Add(new QuizQuestion { QuestionText = "Where should passwords ideally be stored?", Options = new[] { "Notebook", "Browser", "Desktop", "Password manager" }, CorrectIndex = 3, Explanation = "Password managers safely encrypt and store credentials." });
        }

        public class QuizQuestion
        {
            public string QuestionText { get; set; }
            public string[] Options { get; set; }
            public int CorrectIndex { get; set; }
            public string Explanation { get; set; }
        }
    }
}
